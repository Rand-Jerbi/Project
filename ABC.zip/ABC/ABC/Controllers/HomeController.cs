﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ABC.Models;




namespace ABC.Controllers
{
    
   
    [Authorize]
    public class HomeController : Controller
    {
       
        
        ABCDatabaseEntities1 db = new ABCDatabaseEntities1();
        // GET: Home
        [AllowAnonymous]
        public ActionResult Index()
        {
            int hour = DateTime.Now.Hour;
            if (hour < 12)
            {
                ViewBag.Greeting = "Good Morning";
            }
            else
            {
                ViewBag.Greeting = "Good Afternoon";
            }

            ViewBag.Message = "This can be viewed by users";
            
            return View();
        }
        [AllowAnonymous]
        public ActionResult Show()
        {
            ViewBag.curnDate = DateTime.Now.Date+" - "+DateTime.Now.Hour;
            //ViewBag.Customer =;
            ViewBag.Message = "This can be viewed by users";
            return View();
            
        }
        [Authorize ]
        [HttpPost]
        
        public ActionResult show(Complaint c)
        {
            db.Complaints.Add(c);
            db.SaveChanges();
            return RedirectToAction("Index", "Home");
        }
        public ActionResult List()
        {
            ViewBag.Message = "This can be viewed by Admins";
            return View();

        }
    }
}