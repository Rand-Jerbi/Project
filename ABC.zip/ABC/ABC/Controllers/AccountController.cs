﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using ABC.Models;

namespace ABC.Controllers
{
    
    public class AccountController : Controller
    {
      
        ABCDatabaseEntities1 db = new ABCDatabaseEntities1();
        //
        // GET: /Account/
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Customer customer, string ReturnUrl)
        {
            if (ModelState.IsValid)
            {
                Customer ValidUser = db.Customers.Where(c => c.Email == customer.Email && c.Password ==
                 customer.Password).FirstOrDefault();
                // User ValidUser = db.Users.SingleOrDefault(user => user.UserId == u.UserId && user.Password ==c.Password);

                if (ValidUser != null)
                {
                    FormsAuthentication.SetAuthCookie(ValidUser.First_Name, false);
                    if (Url.IsLocalUrl(ReturnUrl))
                    {
                        return Redirect(ReturnUrl);
                    }
                    else
                    {
                        TempData["role"] = "Customer";

                        return RedirectToAction("Index", "Home");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Invalid user, try again");
                    return View();
                }
            }
            else
            {
                return View();
            }
        }
        public ActionResult AdminLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AdminLogin(Admin admin, string ReturnUrl)
        {
            if (ModelState.IsValid)
            {
                Admin ValidUser = db.Admins.Where(a => a.Email == admin.Email && a.Password ==
                 admin.Password).FirstOrDefault();
                
                if (ValidUser != null)
                {
                    FormsAuthentication.SetAuthCookie(ValidUser.First_Name, false);
                    if (Url.IsLocalUrl(ReturnUrl))
                    {
                        return Redirect(ReturnUrl);
                    }
                    else
                    {
                        TempData["role"] = "Admin";
                        return RedirectToAction("index", "Home");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Invalid user, try again");
                    return View();
                }
            }
            else
            {
                return View();
            }
        }
        public ActionResult createAccount()
        {
            return View();
        }
        [HttpPost]
        public ActionResult createAccount(Customer c)
        {
            db.Customers.Add(c);
            db.SaveChanges();
            return RedirectToAction("Index", "Home");
        }
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
    }
}